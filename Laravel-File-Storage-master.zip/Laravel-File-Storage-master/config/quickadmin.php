<?php

return [
    'default_role_id' => 2,
    'can_see_all_records_role_id' => 1
];