<?php

$factory->define(App\Subscription::class, function (Faker\Generator $faker) {
    return [

    ];
});
